﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using System.Net;
using System.Net.Sockets;
using System.Threading;

namespace WindowsFormsApplication1
{
    public partial class Form1 : Form
    {
        Socket server;
        Thread atender;
        int miPartida;
        string fila;
        int tiempo;
        string noaceptan;
        delegate void DelegadoGrid(string[] trozos);
        delegate void DelegadoParaEscribir(string text);
        public Form1()
        {
            InitializeComponent();
        }
        private void GridConectados(string[] res)
        {
            dataGridView1.Rows.Clear();
            dataGridView1.Name = "Conectados";
            dataGridView1.ColumnCount = 2;
            dataGridView1.RowHeadersVisible = false;
            dataGridView1.AutoSizeColumnsMode = DataGridViewAutoSizeColumnsMode.AllCells;
            dataGridView1.AutoSizeRowsMode = DataGridViewAutoSizeRowsMode.DisplayedCellsExceptHeaders;
            dataGridView1.Columns[0].Name = "Jugador";
            dataGridView1.Columns[1].Name = "Socket";
            //contLbl.Text = mensaje;
            int i = 1;
            while (i <= Convert.ToInt32(res[0]))
            {
                int s = (2 * i) - 1;
                int r = 2 * i;
                dataGridView1.Rows.Add(res[s], res[r]);
                i = i + 1;
            }
        }
        private void EscribirChat(string text)
        {
            string Texto = respuestachat.Text;
            this.respuestachat.Text = text + "\n" + Texto;
        }
        private void AtenderServidor()
        {
            while (true)
            {
                byte[] msg2 = new byte[80];
                server.Receive(msg2);
                string[] trozos = Encoding.ASCII.GetString(msg2).Split('/');
                int codigo = Convert.ToInt32(trozos[0]);
                //string mensaje = mensaje = trozos[1].Split('\0')[0];
                string mensaje = trozos[1].Split('\0')[0];

                switch (codigo)
                {
                    case 1:
                        MessageBox.Show(mensaje);
                        break;
                    case 2:
                        MessageBox.Show(mensaje);
                        break;
                    case 3:
                        MessageBox.Show(mensaje);
                        break;
                    case 4:
                        MessageBox.Show(mensaje);
                        break;
                    case 5:
                        MessageBox.Show(mensaje);
                        break;
                    case 6: 
                        string[] res = mensaje.Split('/');
                        dataGridView1.Invoke(new DelegadoGrid(GridConectados), new object[] { res });
                    
                        break;
                    case 7: //invitacion(selecciona jugador del grid de conectados)
                        string[] res7 = mensaje.Split('/');
                        DialogResult result = MessageBox.Show(user.Text + ": " + res7[0] + " le ha invitado a Jugar, desea aceptar la partida?", "Aceptar?", MessageBoxButtons.YesNo);
                        miPartida = Convert.ToInt32(res7[1]);
                        if (result == DialogResult.Yes)
                        {
                            mensaje = "8/SI|" + miPartida + "|";
                            // Enviamos al servidor el nombre tecleado
                            byte[] msg = System.Text.Encoding.ASCII.GetBytes(mensaje);
                            server.Send(msg);
                        }
                        else
                        {
                            mensaje = "8/NO|" + miPartida + "|";
                            // Enviamos al servidor el nombre tecleado
                            byte[] msg = System.Text.Encoding.ASCII.GetBytes(mensaje);
                            server.Send(msg);

                        }
                        break;
                    case 8: //hay partida o no
                        string[] res8 = mensaje.Split('/');
                        if (res8[0] == "SI")
                        {
                            MessageBox.Show("Se ha iniciado la partida");
                            tiempo = 0;
                            miPartida = Convert.ToInt32(res8[1]);
                        }
                        else
                        {
                            int j = 0;
                            while (j < res8.Length)
                            {
                                noaceptan = noaceptan + ", " + res8[j];
                                j = j + 1;
                            }
                            MessageBox.Show("Partida no iniciada, ellos no han aceptado:" + noaceptan);
                        }
                        break;
                    case 9://recibimos la respuesta
                        respuestachat.Invoke(new DelegadoParaEscribir(EscribirChat), new object[] { mensaje });
                        break;
                }
            }
        }
        private void button1_Click(object sender, EventArgs e)
        {
            IPAddress direc = IPAddress.Parse("147.83.117.22"); // 192.168.56.102 192.168.1.127 mia 192.168.56.101 147.83.117.22
            IPEndPoint ipep = new IPEndPoint(direc, 50007); //9001 50007


            //Creamos el socket 
            server = new Socket(AddressFamily.InterNetwork, SocketType.Stream, ProtocolType.Tcp);
            try
            {
                server.Connect(ipep);//Intentamos conectar el socket
                this.BackColor = Color.Green;
                MessageBox.Show("Conectado");

            }
            catch (SocketException ex)
            {
                //Si hay excepcion imprimimos error y salimos del programa con return 
                MessageBox.Show("No he podido conectar con el servidor");
                return;
            }
            ThreadStart ts = delegate { AtenderServidor(); };
            atender = new Thread(ts);
            atender.Start();

        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void Form1_Load(object sender, EventArgs e)
        {

        }

        private void iniciars_Click(object sender, EventArgs e)
        {
            string mensaje = "1/" + user.Text + "/" + pass.Text;
            // Enviamos al servidor el nombre tecleado
            byte[] msg = System.Text.Encoding.ASCII.GetBytes(mensaje);
            server.Send(msg);

         

          
            
        }

        private void register_Click(object sender, EventArgs e)
        {
            string mensaje = "2/" + user.Text + "/" + pass.Text;
            // Enviamos al servidor el nombre tecleado
            byte[] msg = System.Text.Encoding.ASCII.GetBytes(mensaje);
            server.Send(msg);

            
            

        }



        private void button1_Click_1(object sender, EventArgs e)
        {
            if (ganador.Checked)
            {
                string mensaje = "3/" + user.Text + "/" + pass.Text;
                // Enviamos al servidor el nombre tecleado
                byte[] msg = System.Text.Encoding.ASCII.GetBytes(mensaje);
                server.Send(msg);

               
            }
            if (datos.Checked)
            {
                string mensaje = "4/" + user.Text + "/" + pass.Text;
                // Enviamos al servidor el nombre tecleado
                byte[] msg = System.Text.Encoding.ASCII.GetBytes(mensaje);
                server.Send(msg);

         
            }
            if (recovery.Checked)
            {
                string mensaje = "5/" + nombre.Text; 
                // Enviamos al servidor el nombre tecleado
                byte[] msg = System.Text.Encoding.ASCII.GetBytes(mensaje);
                server.Send(msg);

            }
        }
            
            
            

        private void ganador_CheckedChanged(object sender, EventArgs e)
        {

        }

        private void datos_CheckedChanged(object sender, EventArgs e)
        {
        
        }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {

        }

        private void desconectar_Click(object sender, EventArgs e)
        {
            //Mensaje de desconexión
            string mensaje = "0/";

            byte[] msg = System.Text.Encoding.ASCII.GetBytes(mensaje);
            server.Send(msg);

            // Nos desconectamos
            atender.Abort();
            this.BackColor = Color.Gray;
            server.Shutdown(SocketShutdown.Both);
            server.Close();
        }

        private void Invitar_Click_Click(object sender, EventArgs e)
        {
            string mensaje;
            if (fila == null)
                MessageBox.Show("Seleccione con quien quiere jugar");
            else
            {
                mensaje = "8/" + fila + "|";
                byte[] msg = System.Text.Encoding.ASCII.GetBytes(mensaje);
                server.Send(msg);
            }
        }
        private void ListaConectados_CellContentClick(object sender, DataGridViewCellCancelEventArgs e)
        {
            string nombres = (string)dataGridView1.Rows[e.RowIndex].Cells[0].Value;
            int encontrado = 0;
            if (fila != null)
            {
                string Comparar = fila + "/";
                string[] trozos1 = Comparar.Split('/');
                int len = trozos1.Length;
                int contador = 0;
                while ((contador < len) && (encontrado == 0))
                {
                    if (nombres == trozos1[contador])
                        encontrado = 1;
                    contador = contador + 1;
                }
                if (encontrado == 0)
                    fila = fila + '/' + nombres;
            }
            else
            {
                fila = nombres;
            }
        }

        private void enviamensaje_Click(object sender, EventArgs e)
        {
            string mensaje;
            if (textBox1 == null)
                MessageBox.Show("Escribe un mensaje");
            else
            {
                mensaje = "9/" + miPartida + "/" + textBox1.Text;
                byte[] msg = System.Text.Encoding.ASCII.GetBytes(mensaje);
                server.Send(msg);
            }

        }

 
    }
}
